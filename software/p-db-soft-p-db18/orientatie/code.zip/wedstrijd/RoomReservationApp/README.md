# Room Reservation App

**Niet afgemaakt**

## Probleem

Een afdeling in het ziekenhuis is op zoek naar een manier om hun kamers eenvoudig te beheren. Het medische personeel kan een kamers reserveren om patiënten te ontvangen of om ander werk uit te voeren.

Momenteel moet het personeel elke kamer controleren, om te zien of deze vrij is. Dit is erg storend en onprofessioneel tegenover de patiënten, waardoor enige ontevredeheid is ontstaan bij het personeel.

## Oplossing

Een applicatie waarmee het personeel één kamer kan reserveren. Deze gegevens kunnen eventueel op tablets naast de deur worden weergegeven.
