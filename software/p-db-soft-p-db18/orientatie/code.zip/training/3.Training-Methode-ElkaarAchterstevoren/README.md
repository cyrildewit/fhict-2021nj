# Methode Elkaarstevoren

Dit project bestaat uit twee oefeningen. De eerste oefening is afkomsting uit het [softwarematerial](https://stasemsoft.github.io/softwarematerial/docs/basic/) en heet "Training met methode ElkaarAchterstevoren".

De tweede oefening is zelf bedacht en bestaat uit een palindroom tester.
