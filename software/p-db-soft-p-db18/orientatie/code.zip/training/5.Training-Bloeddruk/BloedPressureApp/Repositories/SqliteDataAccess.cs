﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BloedPressureApp
{
    public class SqliteDataAccess
    {
        public static List<PatientModel> LoadPatients()
        {
            using IDbConnection cnn = new SQLiteConnection(LoadConnectionString());
            var output = cnn.Query<PatientModel>("select * from patients", new DynamicParameters());

            return output.ToList();
        }

        public static void SavePatient(PatientModel patient)
        {
            using IDbConnection cnn = new SQLiteConnection(LoadConnectionString());
            cnn.Execute("insert into patients (firstname, lastname, birthdate, gender) values (@FirstName, @LastName, @Birthdate, @Gender)", patient);
        }

        public static void UpdatePatient(PatientModel patient)
        {
            using IDbConnection cnn = new SQLiteConnection(LoadConnectionString());
            string q = string.Concat("UPDATE patients SET firstname = '", patient.FirstName, "', lastname ='", patient.LastName, "', birthdate='", patient.Birthdate, "', gender='", patient.Gender, "' WHERE id =", patient.Id.ToString(), ";");
            cnn.Execute(q, patient);
        }

        public static void DeletePatient(PatientModel patient)
        {
            using IDbConnection cnn = new SQLiteConnection(LoadConnectionString());
            string q = string.Concat("DELETE FROM patients WHERE id =", patient.Id.ToString(), ";");
            cnn.Execute(q, patient);
        }

        public static List<BloodPressureModel> LoadBloodPressureForPatient(PatientModel patient)
        {
            using IDbConnection cnn = new SQLiteConnection(LoadConnectionString());
            string q = string.Concat("SELECT * FROM blood_pressure WHERE patient_id =", patient.Id.ToString(), ";");
            var output = cnn.Query<BloodPressureModel>(q);

            return output.ToList();
        }

        public static void SaveBloodPressure(PatientModel patient, BloodPressureModel bloodPressure)
        {
            using IDbConnection cnn = new SQLiteConnection(LoadConnectionString());
            string q = string.Concat("INSERT INTO blood_pressure (patient_id, upper_pressure, under_pressure, result, notes) values (", patient.Id.ToString(), ", ", bloodPressure.UpperPressure, ", ", bloodPressure.UnderPressure, ", '", bloodPressure.Result, "', '", bloodPressure.Notes, "');");
            cnn.Execute(q);
        }

        private static string LoadConnectionString(string id = "Default")
        {
            return ConfigurationManager.ConnectionStrings[id].ConnectionString;
        }
    }

}
