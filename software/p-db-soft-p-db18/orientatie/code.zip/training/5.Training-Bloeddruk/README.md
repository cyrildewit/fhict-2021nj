# Bloeddruk

Dit project is gebaseerd op een oefening uit [softwarematerial](https://stasemsoft.github.io/softwarematerial/docs/basic/) en heet "Training: Bloeddruk".

De applicatie begint in het patiëntenregister waarin alle patiënten overzichtelijk worden weergeven. Via deze pagina is het mogelijk om een nieuwe patiënt toe te voegen en om een patiënten dossier te beijken. Om een dossier te kunnen inzien, moet er dubbel worden geklikt op een patiënt. In deze omgeving kun je naar de bloeddruk toepassing gaan. Deze toepassing berekent de gemiddelde artiele druk en geeft daarbij een resultaat terug. Indien de behandelaar deze meting wil opslaan in het systeem, kan er op de knop "Toevoegen aan dossier" worden geklikt. Hierbij kunnen ook eventuele aantekingen worden gemaakt.
