# Rock Paper Scissors

Deze opdracht is afkomstig uit het [softwarematerial](https://stasemsoft.github.io/softwarematerial/docs/basic/).
