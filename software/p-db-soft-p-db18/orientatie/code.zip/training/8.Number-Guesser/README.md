# Number Guesser Game

In dit spel moet je het juiste getal raden binnen het aangegeven bereik. Indien de speler een te laag getal invoert, wordt er een aanwijzing gegeven. Hetzelfde geldt voor een te hoog getal. Na het juist gokken van een getal, gaat de speler naar het volgende level.
Met elk level gaat het maximum getal omhoog en wordt het moeilijker om het getal te raden. Punten kunnen verdient worden door in zo'n min mogelijk aantal het juiste getal te raden. De berekening voor het aantal punten is: maximum aantal gokken - aantal gemaakte gokken. Hierbij geldt een minimum van 0.
