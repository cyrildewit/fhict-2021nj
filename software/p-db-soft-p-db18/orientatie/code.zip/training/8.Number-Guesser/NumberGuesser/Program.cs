﻿namespace NumberGuesser
{
    class Program
    {
        static void Main()
        {
            Game game = new Game();
            game.Start();
        }
    }
}
