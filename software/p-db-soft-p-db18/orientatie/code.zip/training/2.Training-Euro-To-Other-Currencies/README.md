# Euro To Other Currencies converter

Dit project is een uitbreiding van de Euro Dollar converter die afkomstig is uit het [softwarematerial](https://stasemsoft.github.io/softwarematerial/docs/basic/).

Door middel van een combobox kan een gewenste valuta worden geselecteerd. De wisselkoersen zijn uiteraard statisch en worden dus niet opgehaald uit een server.
